<?php

namespace Modules\CatalogoEpi\Database\Seeders;

use Illuminate\Database\Seeder;

class CatalogoEpiDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
