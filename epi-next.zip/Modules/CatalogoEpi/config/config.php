<?php

return [
    'name' => 'CatalogoEpi',
];
