<x-catalogoepi::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('catalogoepi.name') !!}</p>
</x-catalogoepi::layouts.master>
