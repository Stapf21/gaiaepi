<?php

return [
    'name' => 'EntradasSaidas',
];
