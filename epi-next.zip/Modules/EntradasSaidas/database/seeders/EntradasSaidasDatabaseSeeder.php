<?php

namespace Modules\EntradasSaidas\Database\Seeders;

use Illuminate\Database\Seeder;

class EntradasSaidasDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
