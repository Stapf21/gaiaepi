<?php

return [
    'name' => 'Dashboard',
];
