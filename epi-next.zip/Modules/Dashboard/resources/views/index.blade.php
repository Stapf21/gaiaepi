<x-dashboard::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('dashboard.name') !!}</p>
</x-dashboard::layouts.master>
