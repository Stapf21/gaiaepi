<?php

namespace Modules\AcidentesRelatorios\Database\Seeders;

use Illuminate\Database\Seeder;

class AcidentesRelatoriosDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
