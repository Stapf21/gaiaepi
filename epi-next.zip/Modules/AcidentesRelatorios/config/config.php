<?php

return [
    'name' => 'AcidentesRelatorios',
];
