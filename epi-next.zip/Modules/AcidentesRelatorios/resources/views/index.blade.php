<x-acidentesrelatorios::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('acidentesrelatorios.name') !!}</p>
</x-acidentesrelatorios::layouts.master>
