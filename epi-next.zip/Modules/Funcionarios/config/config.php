<?php

return [
    'name' => 'Funcionarios',
];
