<?php

namespace Modules\Funcionarios\Database\Seeders;

use Illuminate\Database\Seeder;

class FuncionariosDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
