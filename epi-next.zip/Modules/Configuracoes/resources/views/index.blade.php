<x-configuracoes::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('configuracoes.name') !!}</p>
</x-configuracoes::layouts.master>
