<?php

return [
    'name' => 'Configuracoes',
];
