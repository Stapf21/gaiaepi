<x-treinamentosexames::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('treinamentosexames.name') !!}</p>
</x-treinamentosexames::layouts.master>
