import MovementForm from './MovementForm.jsx';

export default function EntradasSaidasEdit(props) {
    return <MovementForm mode="edit" {...props} />;
}
