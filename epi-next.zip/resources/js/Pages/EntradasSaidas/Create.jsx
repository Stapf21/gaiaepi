import MovementForm from './MovementForm.jsx';

export default function EntradasSaidasCreate(props) {
    return <MovementForm mode="create" {...props} />;
}
