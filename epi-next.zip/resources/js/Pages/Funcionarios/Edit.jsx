import EmployeeForm from './EmployeeForm.jsx';

export default function FuncionariosEdit(props) {
    return <EmployeeForm mode="edit" {...props} />;
}
