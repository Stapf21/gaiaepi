import EmployeeForm from './EmployeeForm.jsx';

export default function FuncionariosCreate(props) {
    return <EmployeeForm mode="create" {...props} />;
}
